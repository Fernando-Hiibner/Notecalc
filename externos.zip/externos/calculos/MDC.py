while True:
   try:
      print("#---------#")
      print("#-- MDC --#")
      print("#---------#")
      resp = int(input('Você deseja calcular um MDC com 2 ou 3 números:\n>'))
      if resp == 2:
         n = int(input('Digite o primeiro valor para o mdc:\n>'))
         n2 = int(input('Digite o segundo valor para o mdc:\n>'))
         resto = n%n2
         lista = [n2, resto]

         while resto > 0:
            resto = lista[-2]%lista[-1]
            lista.append(resto)

         print(f'O MDC entre os valores {n} e {n2} é: {lista[-2]}')

      elif resp == 3:
         n = int(input('Digite o primeiro valor para o mdc:\n>'))
         n2 = int(input('Digite o segundo valor para o mdc:\n>'))
         n3 = int(input('Digite o terceiro valor para o mdc:\n>'))
         resto = n%n2
         lista = [n2, resto]

         while resto > 0:
            resto = lista[-2]%lista[-1]
            lista.append(resto)

         resto2 = lista[-2]%n3
         lista2 = [n2, resto2]

         while resto2 > 0:
            resto2 = lista2[-2]%lista2[-1]
            lista2.append(resto2)

         print(f'O MDC entre os valores {n}, {n2} e {n3}: {lista2[-2]}')
      continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
      if continuar == 1:
         pass
      elif continuar == 2:
         break
   except:
        pass
