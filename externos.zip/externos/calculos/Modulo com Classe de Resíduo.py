#Criador de Código#
import os
while True:
    try:
        print("#----------------------------------#")
        print("#-- Módulo com Classe de Resíduo --#")
        print("#----------------------------------#")
        Alfa = []
        index = 1
        while True:
            M = int(input("Digite o número que vai dividir:\n>"))
            C = int(input("Digite o comeco do intervalo:\n>"))
            R = int(input("Digite o até que número vai o código:\n>"))
            CR = int(input("Digite o número da classe de resíduo\n>"))
            for i in range(C,R+1):
                if i%M == CR:
                    Alfa.append(i)
                else:
                    pass
            for i in range(len(Alfa)):
                print(f"{Alfa[i]:^2}", end = " ")
            print()
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass
#-----#
