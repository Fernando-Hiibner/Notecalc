#Exercício 11 - Revisão Maurício#
#Elabore um algoritmo que leia 2 matrizes A mxn e B pxq, onde m, n, p e q podem
#assumir valores de no máximo 20 (linhas ou colunas). Em seguida verifique se é
#possível calcular a soma destas matrizes e caso seja, calcule e mostre a matriz C
#resultante da soma das matrizes A e B.
from random import *
while True:
    try:
        print("#----------------------#")
        print("#-- Soma de Matrizes --#")
        print("#----------------------#")
        LA = int(input("Digite um valor de Linhas para a Matriz A (Não deve ser maior que 20)\n>"))
        CA = int(input("Digite um valor de Colunas para a Matriz A (Não deve ser maior que 20)\n>"))
        LB = int(input("Ditite um valor de Linhas para a Matriz B (Não deve ser maior que 20)\n>"))
        CB = int(input("Digite um valor de Colunas para a Matriz B (Não deve ser maior que 20)\n>"))
        A = [0]*LA
        B = [0]*LB
        for i in range(LA):
            A[i] = [0]*CA
            for j in range(CA):
                A[i][j] = int(input(f"Digite o valor do elemento A[{i}][{j}]:\n>"))
                #A[i][j] = randint(1,50)
        for i in range(LB):
            B[i] = [0]*CB
            for j in range(CB):
                B[i][j] = int(input(f"Digite o valor do elemento B[{i}][{j}]:\n>"))
                #B[i][j] = randint(1,50)
        for i in range(LA):
            for j in range(CA):
                print(f"|{A[i][j]:^2}|", end = " ")
            print()
        print()
        for i in range(LB):
            for j in range(CB):
                print(f"|{B[i][j]:^2}|", end = " ")
            print()
        print()
        if LA == LB and CA == CB:
            S = [0]*LA
            for i in range(CA):
                S[i] = [0]*CA
            for i in range(LA):
                for j in range(CA):
                    S[i][j] = A[i][j]+B[i][j]
            print("A soma dessas matrizes é:")
            for i in range(LB):
                for j in range(CB):
                    print(f"|{S[i][j]:^2}|", end = " ")
                print()
        else:
            print("\nNão é possível somar essas Matrizes")
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass
