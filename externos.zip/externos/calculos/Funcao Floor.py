#Floor#
while True:
    try:
        print("#------------------#")
        print("#-- Função Floor --#")
        print("#------------------#")
        floor = float(input("Digite um número:\n>"))
        floor = int(floor)
        print(floor)
        print("#------------#")
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass
#-----#
