#Resto#
while True:
    try:
        print("#------------------#")
        print("#-- Função Resto --#")
        print("#------------------#")
        while True:
            k = float(input("Digite o número a ser dividido:\n>"))
            M = float(input("Digite o número que vai dividir:\n>"))
            if k > 0:
                a = k%M
                b = a
            elif k < 0:
                k *= -1
                a = k%M
                b = M - a
            print("k(mod M) =", b)
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass
#-----#
