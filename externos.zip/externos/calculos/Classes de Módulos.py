while True:
    try:
        print('#------------------------#')
        print('#-- Classes de Módulos --#')
        print('#------------------------#')
        m = int(input("Digite o número 'm':\n>"))
        c = int(input("Digite o inicio do intervalo:\n>"))
        f = int(input("Digite o fim do intervalo:\n>"))
        listap = [0]*m
        for i in range(m):
            listap[i] = [0]
            for j in range(m):
                listap[i][0] = m+i
        for i in range(m):
            while True:
                ini = listap[i][0]
                ini -= m
                if ini > c :
                    listap[i].insert(0, ini)
                else:
                    break
            while True:
                ini2 = listap[i][len(listap[i])-1]
                ini2 += m
                if ini2 < f:
                    listap[i].append(ini2)
                else:
                    break
        for i in range(m):
            for j in range(len(listap[i])-1):
                print(f"{listap[i][j]}", end = " ")
            print()
            continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass

    
