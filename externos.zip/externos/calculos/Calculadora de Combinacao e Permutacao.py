def fat(n):
    for i in range(n-1,0,-1):
        n *= i
    return n
while True:
    try:
        print('#--------------------------------------------#')
        print('#-- Calculadora de Combinação e Permutação --#')
        print('#--------------------------------------------#')
        E = int(input("Você deseja calcular combinação (Digite 1) ou permutação (Digite 2):\n>"))
        Nr = []
        Nrf = []
        M = 1
        if E == 1:
            n = int(input("Por gentileza digite o número de elementos:\n>"))
            r = int(input("Por gentileza digite a taxa de combinação:\n>"))
            resp = (fat(n)/fat(n-r))/fat(r)
            print(f"A resposta dessa combinação é: {resp}")
        elif E == 2:
            n = int(input("Por gentileza digite o número de elementos:\n>"))
            r = int(input("Por gentileza digite a taxa de combinação:\n>"))
            if n > r:
                resp = fat(n)/fat(n-r)
                print(f"A resposta dessa permutação é: {resp}")
            elif n == r:
                qr = int(input("Por gentileza digite o número de elementos que repetem:\n>"))
                for i in range(qr):
                    Nr.append(int(input(f"Quantas vezes o {i+1}º elemento a repetir se repete:\n>")))
                for i in range(len(Nr)):
                    Nrf.append(fat(Nr[i]))
                for i in range(len(Nrf)):
                    M *= Nrf[i]
                resp = fat(n)/M
                print(f"A resposta dessa permutação é: {resp}")
            else:
                print("Essa permutação não tem resposta")
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass

