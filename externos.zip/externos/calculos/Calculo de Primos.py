def primos(comeco, fim):
    lista = []
    for n in range(comeco, fim+1):
        if n>1:
            for i in range(2, n):
                if n%2 == 0:
                    break
            else:
                lista.append(n)
    return lista
def maiorprimo(r):
    maior = 0
    for n in range(1, r+1):
        if n>1:
            for i in range(2, n):
                if n%2 == 0:
                    break
            else:
                maior = n
    return maior
while True:
    try:
        print("#-----------------------#")
        print("#-- Calculo de Primos --#")
        print("#-----------------------#")

        print("Qual calulo deseja efetuar:")
        print("1 - Todos os primos dentro de determinado intervalo")
        print("2 - O maior primo até determinado número")
        d = int(input("Digite o número correspondente a sua escolha:\n>"))
        if d == 1:
            com = int(input("Digite o começo do intervalo:\n>"))
            fim = int(input("Digite o fim do intervalo:\n>"))
            print("#--------------#")
            print("#-- Resposta --#")
            print("#--------------#")
            lista = primos(com, fim)
            for i in range(len(lista)):
                print(f"|{lista[i]:^2}|", end = " ")
            print()
        elif d == 2:
            r = int(input("Digite o número:\n>"))
            print("#--------------#")
            print("#-- Resposta --#")
            print("#--------------#")
            maior = maiorprimo(r)
            print(f"|{maior}|")
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass



    

