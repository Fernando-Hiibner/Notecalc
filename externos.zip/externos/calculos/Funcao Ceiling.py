#Ceiling#
while True:
    try:
        print("#--------------------#")
        print("#-- Função Ceiling --#")
        print("#--------------------#")
        ceiling = float(input("Digite um número:\n>"))
        if ceiling == int(ceiling):
            ceiling = int(ceiling)
        else:
            ceiling = int(ceiling) + 1
        print(ceiling)
        print("#------------#")
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass
#-------#
