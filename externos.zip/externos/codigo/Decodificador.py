#Decodificador#
import os
while True:
        try:
                print("#-------------------#")
                print("#-- Decodificador --#")
                print("#-------------------#")
                Chave = input("Digite o nome da chave que você deseja usar(Escreva exatamente como ela se chama):\n>")
                with open(f"{Chave}.txt", "r") as Cha:
                    Num = Cha.read()
                    Cha.close()
                Nums = Num.split("-")

                M = int(Nums[0])
                R = int(Nums[1])
                CR = int(Nums[2])
                Alfa = []
                Alfa2 = ["A","a","B","b","C","c","D","d","E","e","F","f","G","g","H","h","I","i","J","j","K","k","L","l","M","m","N","n","O","o","P","p","Q","q","R","r","S","s","T","t","U","u","V","v","X","x","W","w","Y","y","Z","z"," ","/","-","0","1","2","3","4","5","6","7","8","9"]
                for i in range(1,R+1):
                        if i%M == CR:
                            i = str(i)
                            if len(i) == 1:
                                i = str("0"+"0"+i)
                            elif len(i) == 2:
                                i = str("0"+i)
                            elif len(i) == 3:
                                i = str(i)
                            Alfa.append(i)
                        else:
                            pass
                while True:
                    Cod = input("Digite o código:\n")
                    Cods = Cod.split(".")
                    TextoFinal = ""
                    for i in range(len(Cods)):
                        if Cods[i] in Alfa:
                                B = Alfa.index(Cods[i])
                                B = Alfa2[B]
                                TextoFinal = TextoFinal+B
                        else:
                                pass
                    print(TextoFinal)
                continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
                if continuar == 1:
                    pass
                elif continuar == 2:
                    break
        except:
                pass
                            
    
    
