#Criador de Código#
import os
from random import *
while True:
    try:
        print("#-----------------------#")
        print("#-- Criador de Código --#")
        print("#-----------------------#")
        Alfa = ["A = ","a = ", "B = ","b = ", "C = ","c = ", "D = ","d = ", "E = ","e = ", "F = ","f = ", "G = ","g = ", "H = ","h = ", "I = ","i = ", "J = ","j = ", "K = ","k = ", "L = ","l = ", "M = ","m = ", "N = ","n = ", "O = ","o = ", "P = ","p = ", "Q = ","q = ", "R = ","r = ", "S = ","s = ", "T = ","t = ", "U = ","u = ", "V = ","v = ", "X = ","x = ", "W = ","w = ", "Y = ","y = ", "Z = ","z = ", "ESPAÇO = ","/ =","- =", "0 = ", "1 = ", "2 = ", "3 = ", "4 = ", "5 = ", "6 = ", "7 = ", "8 = ", "9 = "]
        index = 1
        while True:
            M = randint(1,50)
            R = randint(1,6500)
            CR = randint(1,25)
            for i in range(1,R+1):
                if i%M == CR:
                    i = str(i)
                    if len(i) == 1:
                        i = str(" "+"0"+"0"+i+"\n")
                    elif len(i) == 2:
                        i = str(" "+"0"+i+"\n")
                    else:
                        i = str(" "+i+"\n")
                    Alfa.insert(index, i)
                    index += 2
                else:
                    pass
            if len(Alfa) == 130:
                print(f"É possivel fazer alfabeto com essa combinação de divisor {M}, até o número {R} e classe de resíduo {CR}, o nome da Chave é: Chave {M}-{R}-{CR}")
                Chave = f"{M}-{R}-{CR}"
                with open(f"Chave {M}-{R}-{CR}.txt", "a+") as Cha:
                    Cha.write(Chave)
                    Cha.close()
                with open(f"Alfabeto {M}-{R}-{CR}.txt", "a+") as Alf:
                    for i in range(len(Alfa)):
                        Alf.write(Alfa[i])
                    Alf.close()
                Alfa = ["A = ","a = ", "B = ","b = ", "C = ","c = ", "D = ","d = ", "E = ","e = ", "F = ","f = ", "G = ","g = ", "H = ","h = ", "I = ","i = ", "J = ","j = ", "K = ","k = ", "L = ","l = ", "M = ","m = ", "N = ","n = ", "O = ","o = ", "P = ","p = ", "Q = ","q = ", "R = ","r = ", "S = ","s = ", "T = ","t = ", "U = ","u = ", "V = ","v = ", "X = ","x = ", "W = ","w = ", "Y = ","y = ", "Z = ","z = ", "ESPAÇO = ","/ =","- =", "0 = ", "1 = ", "2 = ", "3 = ", "4 = ", "5 = ", "6 = ", "7 = ", "8 = ", "9 = "]
                index = 1
                break
            else:
                Alfa = ["A = ","a = ", "B = ","b = ", "C = ","c = ", "D = ","d = ", "E = ","e = ", "F = ","f = ", "G = ","g = ", "H = ","h = ", "I = ","i = ", "J = ","j = ", "K = ","k = ", "L = ","l = ", "M = ","m = ", "N = ","n = ", "O = ","o = ", "P = ","p = ", "Q = ","q = ", "R = ","r = ", "S = ","s = ", "T = ","t = ", "U = ","u = ", "V = ","v = ", "X = ","x = ", "W = ","w = ", "Y = ","y = ", "Z = ","z = ", "ESPAÇO = ","/ =","- =", "0 = ", "1 = ", "2 = ", "3 = ", "4 = ", "5 = ", "6 = ", "7 = ", "8 = ", "9 = "]
                index = 1
        continuar = int(input("Quer continuar? (1 para SIM/2 para NÃO):\n>"))
        if continuar == 1:
            pass
        elif continuar == 2:
            break
    except:
        pass
#-----#
